import { Component } from '@angular/core';
import { BookAddComponent } from "../book-add/book-add.component";

@Component({
  selector: 'app-booklist',
  standalone: true,
  imports: [BookAddComponent],
  templateUrl: './booklist.component.html',
  styleUrl: './booklist.component.css'
})
export class BooklistComponent {
  books = [
    {id : 1, title : "Atomic Habits", author : "James Clear", price : 35},
    {id : 2, title : "Atomic Habits 2", author : "James Clear", price : 35},
    {id : 3, title : "Atomic Habits 3", author : "James Clear", price : 35}
]
action=""
changeAction(action: string) {
  this.action = action;
}
}
